GITHUB PAGES SETUP

Keep these two files together in the ROOT of your GitHub repository:
- index.html
- meme.mp4

Then open the repository Settings > Pages.
Under Build and deployment, choose "Deploy from a branch".
Choose branch "main" and folder "/ (root)", then Save.
Wait a few minutes and open the URL shown in Settings > Pages.

IMPORTANT:
- Do not upload only index.html; meme.mp4 must also be in the repository root.
- The site is public when published with GitHub Pages. Anyone with the link may view it.
- Phones may block autoplay with sound. The video controls are shown so the viewer can tap Play.
